"""Score entry and result calculations."""

SUBJECTS = ("English", "Mathematics", "Biology", "Chemistry", "Physics")


def calculate_total(scores):
    """Return the total of the scores supplied."""
    return sum(float(score) for score in scores.values())


def calculate_average(scores):
    """Return the average, or None when no scores have been entered."""
    if not scores:
        return None
    return calculate_total(scores) / len(scores)


def get_grade(average):
    """Use the grade scale from the original Document 2 project."""
    if average is None:
        return "N/A"
    if average >= 80:
        return "A"
    if average >= 70:
        return "B"
    if average >= 60:
        return "C"
    if average >= 50:
        return "D"
    return "F"


def grade_description(grade):
    return {
        "A": "Excellent",
        "B": "Very Good",
        "C": "Good",
        "D": "Pass",
        "F": "Fail",
        "N/A": "No result recorded",
    }.get(grade, "Unknown grade")


def read_score(subject):
    """Keep asking until a valid score between 0 and 100 is entered."""
    while True:
        raw = input(f"Enter score for {subject} (0-100): ").strip()
        try:
            score = float(raw)
        except ValueError:
            print("Please enter a valid number.")
            continue
        if 0 <= score <= 100:
            return score
        print("Score must be between 0 and 100.")


def record_scores(student):
    """Enter or replace the student's scores for all five subjects."""
    print("\nEnter scores from 0 to 100. All five subjects are required.")
    for subject in SUBJECTS:
        student.scores[subject] = read_score(subject)
    from datetime import date
    student.result_date = date.today().strftime("%d/%m/%Y")
