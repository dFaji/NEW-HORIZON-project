"""Student record model for the Student Result Management System."""
from dataclasses import dataclass, field


@dataclass
class Student:
    student_id: str
    full_name: str
    class_form: str
    gender: str
    date_of_birth: str
    scores: dict[str, float] = field(default_factory=dict)
    result_date: str = ""

    def __post_init__(self):
        # Keep this blank until a result is actually entered.
        # The date is updated by the score-entry functions.
        if self.result_date is None:
            self.result_date = ""

    def to_dictionary(self):
        """Convert the student object to a JSON-compatible dictionary."""
        return {
            "student_id": self.student_id,
            "full_name": self.full_name,
            "class_form": self.class_form,
            "gender": self.gender,
            "date_of_birth": self.date_of_birth,
            "scores": self.scores,
            "result_date": self.result_date,
        }

    @classmethod
    def from_dictionary(cls, data):
        """Build a student object from a saved dictionary."""
        if not isinstance(data, dict):
            raise ValueError("A student record must be a dictionary.")
        return cls(
            student_id=str(data.get("student_id", "")),
            full_name=str(data.get("full_name", "")),
            class_form=str(data.get("class_form", "")),
            gender=str(data.get("gender", "")),
            date_of_birth=str(data.get("date_of_birth", "")),
            scores=data.get("scores", {}) if isinstance(data.get("scores", {}), dict) else {},
            result_date=str(data.get("result_date", "")),
        )
