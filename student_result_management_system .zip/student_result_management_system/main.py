"""Main menu for the Student Result Management System."""
from datetime import datetime
from student import Student
from storage import load_students, save_students
from results import SUBJECTS, record_scores, calculate_average, read_score
from reports import student_report, all_results_report, class_statistics, save_text_report


def find_student(students, student_id):
    """Find a student by ID without considering letter case."""
    return next((student for student in students
                 if student.student_id.lower() == student_id.strip().lower()), None)


def read_required(prompt):
    while True:
        value = input(prompt).strip()
        if value:
            return value
        print("This field cannot be empty.")


def read_date_of_birth(prompt="Date of birth (DD/MM/YYYY): "):
    while True:
        value = input(prompt).strip()
        try:
            datetime.strptime(value, "%d/%m/%Y")
            return value
        except ValueError:
            print("Enter a valid date in DD/MM/YYYY format, for example 07/04/2005.")


def add_student(students):
    print("\n--- Register Student ---")
    student_id = read_required("Student ID: ")
    if find_student(students, student_id):
        print("That student ID already exists.")
        return
    name = read_required("Full name: ")
    student_class = read_required("Class/Form: ")
    gender = read_required("Gender: ")
    dob = read_date_of_birth()
    student = Student(student_id, name, student_class, gender, dob)
    print("Would you like to enter scores now? (y/n)")
    if input("Choice: ").strip().lower() == "y":
        record_scores(student)
    students.append(student)
    save_students(students)
    print(f"{name} registered successfully.")


def view_students(students):
    if not students:
        print("No students have been registered yet.")
        return
    print("\n--- Registered Students ---")
    print(f"{'ID':<15}{'FULL NAME':<30}{'CLASS/FORM':<15}{'RESULT':<10}")
    print("-" * 70)
    for student in students:
        status = "Complete" if calculate_average(student.scores) is not None else "Pending"
        print(f"{student.student_id:<15}{student.full_name[:29]:<30}{student.class_form[:14]:<15}{status:<10}")


def search_student(students):
    term = input("Enter student ID or part of the name: ").strip().lower()
    if not term:
        print("Enter an ID or name to search for.")
        return
    matches = [student for student in students
               if term in student.student_id.lower() or term in student.full_name.lower()]
    if not matches:
        print("No matching student was found.")
        return
    for student in matches:
        print(student_report(student))


def update_student(students):
    student = find_student(students, input("Enter student ID to update: "))
    if student is None:
        print("Student not found.")
        return
    print("Leave a field blank to keep the current value.")
    name = input(f"Full name [{student.full_name}]: ").strip()
    student_class = input(f"Class/Form [{student.class_form}]: ").strip()
    gender = input(f"Gender [{student.gender}]: ").strip()
    dob = input(f"Date of birth [{student.date_of_birth}]: ").strip()
    if name:
        student.full_name = name
    if student_class:
        student.class_form = student_class
    if gender:
        student.gender = gender
    if dob:
        try:
            datetime.strptime(dob, "%d/%m/%Y")
        except ValueError:
            print("Invalid date. Student details were not saved; use DD/MM/YYYY.")
            return
        student.date_of_birth = dob
    save_students(students)
    print("Student information updated.")


def delete_student(students):
    student = find_student(students, input("Enter student ID to delete: "))
    if student is None:
        print("Student not found.")
        return
    confirmation = input(f"Delete {student.full_name}? Type YES to confirm: ").strip()
    if confirmation == "YES":
        students.remove(student)
        save_students(students)
        print("Student record deleted.")
    else:
        print("Deletion cancelled.")


def update_scores(students):
    student = find_student(students, input("Enter student ID: "))
    if student is None:
        print("Student not found. Register the student first.")
        return
    print("1. Enter/update all five scores")
    print("2. Update one subject score")
    choice = input("Choose an option: ").strip()
    if choice == "1":
        record_scores(student)
    elif choice == "2":
        for subject in SUBJECTS:
            print(f"{subject}: {student.scores.get(subject, 'Not entered')}")
        subject_name = input("Enter subject name: ").strip().title()
        if subject_name not in SUBJECTS:
            print("Subject not recognised. Please use a subject shown above.")
            return
        student.scores[subject_name] = read_score(subject_name)
        student.result_date = datetime.now().strftime("%d/%m/%Y")
    else:
        print("Invalid option.")
        return
    save_students(students)
    print("Scores saved successfully.")


def show_one_report(students):
    student = find_student(students, input("Enter student ID: "))
    if student is None:
        print("Student not found.")
    else:
        print(student_report(student))


def sort_students(students):
    if not students:
        print("No student records to sort.")
        return
    print("1. Sort by average (highest to lowest)")
    print("2. Sort by name (A-Z)")
    choice = input("Choose sorting option: ").strip()
    if choice == "1":
        ordered = sorted(students, key=lambda item: (
            calculate_average(item.scores) is not None,
            calculate_average(item.scores) if calculate_average(item.scores) is not None else -1
        ), reverse=True)
    elif choice == "2":
        ordered = sorted(students, key=lambda item: item.full_name.lower())
    else:
        print("Invalid option.")
        return
    print(all_results_report(ordered))


def menu():
    students = load_students()
    actions = {
        "1": lambda: add_student(students),
        "2": lambda: view_students(students),
        "3": lambda: search_student(students),
        "4": lambda: update_student(students),
        "5": lambda: delete_student(students),
        "6": lambda: update_scores(students),
        "7": lambda: show_one_report(students),
        "8": lambda: print(all_results_report(students)),
        "9": lambda: sort_students(students),
        "10": lambda: print(class_statistics(students)),
        "11": lambda: print(f"Report saved to: {save_text_report(students)}"),
    }
    while True:
        print("\n" + "=" * 45)
        print("       STUDENT RESULT MANAGEMENT SYSTEM")
        print("=" * 45)
        print("1. Register a student")
        print("2. View all students")
        print("3. Search for a student")
        print("4. Update student information")
        print("5. Delete a student")
        print("6. Enter/update subject scores")
        print("7. Display an individual report card")
        print("8. View all results (ranked by average)")
        print("9. Sort results")
        print("10. Show class statistics")
        print("11. Save results report to text file")
        print("0. Save and exit")
        choice = input("Enter your choice: ").strip()
        if choice == "0":
            try:
                save_students(students)
            except OSError as error:
                print(error)
                print("The program is exiting, but the latest changes may not have been saved.")
            else:
                print("Student data saved. Goodbye!")
            break
        action = actions.get(choice)
        if action is None:
            print("Invalid choice. Please choose one of the menu numbers.")
            continue
        try:
            action()
        except (OSError, ValueError) as error:
            print(f"Operation failed: {error}")


if __name__ == "__main__":
    menu()
