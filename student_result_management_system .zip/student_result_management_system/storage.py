"""Load and save student records in a JSON file."""
import json
from pathlib import Path
from student import Student

PROJECT_FOLDER = Path(__file__).resolve().parent
DATA_FOLDER = PROJECT_FOLDER / "data"
DATA_FILE = DATA_FOLDER / "students.json"


def load_students(filename=DATA_FILE):
    """Load saved students; return an empty list if no file exists yet."""
    path = Path(filename)
    if not path.exists():
        path.parent.mkdir(parents=True, exist_ok=True)
        return []
    try:
        with path.open("r", encoding="utf-8") as file:
            data = json.load(file)
        if not isinstance(data, list):
            raise ValueError("The saved data must contain a list of students.")
        students = [Student.from_dictionary(item) for item in data]
        return students
    except (json.JSONDecodeError, OSError, ValueError, TypeError) as error:
        print(f"Could not load student records: {error}")
        print("The existing file has not been overwritten. Starting with an empty session.")
        return []


def save_students(students, filename=DATA_FILE):
    """Save records safely using a temporary file before replacing the old file."""
    path = Path(filename)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary_path = path.with_suffix(path.suffix + ".tmp")
    try:
        with temporary_path.open("w", encoding="utf-8") as file:
            json.dump([student.to_dictionary() for student in students], file, indent=4)
        temporary_path.replace(path)
    except OSError as error:
        raise OSError(f"Could not save student records: {error}") from error
    finally:
        # A failed write can leave a temporary file behind. Clean it up safely.
        try:
            if temporary_path.exists():
                temporary_path.unlink()
        except OSError:
            # Do not hide the original save error if cleanup also fails.
            pass
