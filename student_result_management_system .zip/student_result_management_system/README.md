# Student Result Management System

## Project overview
This is an improved, beginner-friendly Python console application for managing student details and academic results. It builds on the original `student_result_system 2.zip` project and keeps its five subjects and grade scale while improving code organization, validation, storage, and reporting.

## Features
- Register students and prevent duplicate student IDs (IDs are case-insensitive).
- View all registered students and search by ID or part of a name.
- Update student details and delete records with confirmation.
- Enter all five subject scores or update one subject score.
- Validate scores from 0 to 100 and validate dates in `DD/MM/YYYY` format.
- Calculate totals, averages, grades, and grade descriptions.
- Display individual report cards and a class results table ranked by average.
- Sort results by average or student name.
- Calculate highest and lowest individual subject scores, highest and lowest student averages, and class average using students with recorded results.
- Save class results and statistics to a text report.
- Persist student records in JSON, with data stored relative to the project folder rather than the terminal's current folder.
- Use separate modules for student data, results, storage, reports, and menu operations.

## Requirements
- Python 3.10 or newer recommended.
- No third-party libraries are required.
- Visual Studio Code or another Python editor is optional.

## How to run
1. Extract this ZIP file.
2. Open the extracted `student_result_system_improved` folder in VS Code.
3. Open a terminal in that folder.
4. Run:
   ```bash
   python main.py
   ```
   On Windows, you can also try `py main.py`.
5. Follow the menu options displayed in the terminal.

## Subjects
The default subjects are English, Mathematics, Biology, Chemistry, and Physics. To change them, edit the `SUBJECTS` tuple in `results.py`.

## Grade scale
This preserves the scale in the original Document 2 project:
- A: 80–100
- B: 70–79.99
- C: 60–69.99
- D: 50–59.99
- F: below 50

## Project files
- `main.py` — menu, registration, searching, updates, and user interactions.
- `student.py` — Student dataclass and conversion to/from dictionaries.
- `results.py` — subjects, score input, total/average calculation, and grading.
- `storage.py` — JSON loading and saving, including temporary-file cleanup with `finally` during save operations.
- `reports.py` — individual report cards, ranked class results, statistics, and text report export.
- `data/students.json` — saved student records; created automatically if missing.
- `tests/test_project.py` — basic automated tests for calculations, grades, model conversion, and reports.

## Testing
Run the included tests from the project folder:
```bash
python -m unittest discover -s tests -v
```

The tests check core functions, but you should also run the program and manually test each menu option before submitting it. The project uses `try`, `except`, `else`, and `finally` in appropriate error-handling flows.

## Data note
The project stores student names, dates of birth, and scores in a local JSON file. Use fictional data while practising and do not publish real student records.
