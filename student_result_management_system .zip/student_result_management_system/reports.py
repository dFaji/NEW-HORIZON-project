"""Create student report cards, class reports, and class statistics."""
from datetime import datetime
from pathlib import Path
from results import SUBJECTS, calculate_total, calculate_average, get_grade, grade_description


def student_report(student):
    average = calculate_average(student.scores)
    grade = get_grade(average)
    lines = [
        "=" * 50,
        "                 STUDENT REPORT CARD",
        "=" * 50,
        f"Student ID: {student.student_id}",
        f"Name: {student.full_name}",
        f"Class/Form: {student.class_form}",
        f"Gender: {student.gender}",
        f"Date of birth: {student.date_of_birth}",
        "-" * 50,
        "SUBJECT SCORES",
    ]
    for subject in SUBJECTS:
        if subject in student.scores:
            lines.append(f"{subject:<18} {student.scores[subject]:>7.2f}")
        else:
            lines.append(f"{subject:<18} {'Not entered':>11}")
    lines.extend([
        "-" * 50,
        f"Total: {calculate_total(student.scores):.2f}",
        f"Average: {average:.2f}" if average is not None else "Average: Not available",
        f"Grade: {grade} ({grade_description(grade)})",
        f"Result entered/updated: {student.result_date or 'Not recorded'}",
        "=" * 50,
    ])
    return "\n".join(lines)


def all_results_report(students):
    """Return a class results report sorted by average, highest first."""
    if not students:
        return "No student records available."
    ranked = sorted(
        students,
        key=lambda student: (calculate_average(student.scores) is not None,
                             calculate_average(student.scores) or -1),
        reverse=True,
    )
    lines = ["CLASS RESULTS", "=" * 78,
             f"{'POS':<5}{'ID':<14}{'NAME':<25}{'TOTAL':>10}{'AVERAGE':>12}{'GRADE':>8}",
             "-" * 78]
    position = 0
    for student in ranked:
        average = calculate_average(student.scores)
        grade = get_grade(average)
        if average is not None:
            position += 1
            pos_text = str(position)
            average_text = f"{average:.2f}"
        else:
            pos_text = "-"
            average_text = "N/A"
        lines.append(
            f"{pos_text:<5}{student.student_id[:13]:<14}{student.full_name[:24]:<25}"
            f"{calculate_total(student.scores):>10.2f}{average_text:>12}{grade:>8}"
        )
    lines.append("=" * 78)
    return "\n".join(lines)


def class_statistics(students):
    completed = [(student, calculate_average(student.scores)) for student in students]
    completed = [(student, average) for student, average in completed if average is not None]
    if not completed:
        return "No completed results are available to analyse."
    averages = [average for _, average in completed]
    highest_student, highest = max(completed, key=lambda item: item[1])
    lowest_student, lowest = min(completed, key=lambda item: item[1])
    class_average = sum(averages) / len(averages)

    scored_subjects = [
        (score, student.full_name, subject)
        for student in students
        for subject, score in student.scores.items()
    ]
    highest_score, high_name, high_subject = max(scored_subjects, default=(None, None, None))
    lowest_score, low_name, low_subject = min(scored_subjects, default=(None, None, None))
    lines = [
        "CLASS STATISTICS", "=" * 48,
        f"Registered students: {len(students)}",
        f"Students with results: {len(completed)}",
        f"Students without results: {len(students) - len(completed)}",
        f"Highest subject score: {highest_score:.2f} ({high_name}, {high_subject})" if highest_score is not None else "Highest subject score: Not available",
        f"Lowest subject score: {lowest_score:.2f} ({low_name}, {low_subject})" if lowest_score is not None else "Lowest subject score: Not available",
        f"Highest student average: {highest:.2f} ({highest_student.full_name})",
        f"Lowest student average: {lowest:.2f} ({lowest_student.full_name})",
        f"Class average: {class_average:.2f}",
        "=" * 48,
    ]
    return "\n".join(lines)


def save_text_report(students, filename=None):
    if filename is None:
        filename = Path(__file__).resolve().parent / "results_report.txt"
    else:
        filename = Path(filename)
    content = ["STUDENT RESULT MANAGEMENT SYSTEM REPORT",
               f"Generated: {datetime.now().strftime('%d/%m/%Y %H:%M')}", ""]
    content.append(all_results_report(students))
    content.extend(["", class_statistics(students), ""])
    try:
        filename.write_text("\n".join(content), encoding="utf-8")
    except OSError as error:
        raise OSError(f"Could not create report: {error}") from error
    return filename
